# Etapa 1 do Trabalho de SD

Alunos:<br /> 11711BCC004 - Estela Ferreira Silva<br />
        11711BCC012 - Matheus Dias Gama<br />
        11711BCC022 - Roxanne Silva Julia<br />


Para executar cada servidor, na pasta "server" execute:<br />
```python serverA.py```<br />
```python serverB.py```<br />
```python serverC.py```<br />
<br />
Na pasta "client" execute:<br />
```python client.py```